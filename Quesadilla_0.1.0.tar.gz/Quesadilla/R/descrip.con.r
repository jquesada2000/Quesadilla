


#' @title Descriptive quantitative explanatory variables
#' @description Calculation of descriptive statistics for quantitative variable.
#' @param var Data vector of quantitative variable
#' @returns A data.frame with number, min, max, mean, SD, median, IQR
#' @examples
#' x <- rnorm(100, 0, 1)
#' descrip.con(x)
#' @export
descrip.con <- function ( var ) {

  if ( is.factor(var) == TRUE )
  { stop ( "Error: The variable is a factor" ) }

  nvalido = sum(!is.na(var))
  minimo = round(min(var, na.rm=TRUE),1)
  maximo = round(max(var, na.rm=TRUE),1)
  mean = round(mean (var, na.rm=TRUE),2)
  median = round(median(var, na.rm=TRUE),2)

  sd = round(sd (var, na.rm=TRUE),2)
  iqr = round(IQR (var, na.rm=TRUE),2)

  data.frame ( nvalid=nvalido, Min=minimo, Max=maximo,Mean=mean,SD=sd, Median=median,IQR=iqr)
}
